# CS498-Project
This is a web application built and designed for the CS 498 course at the University of Kentucky.

Our completed application is deployed on Vercel here: https://nextjs-vercel-omega-one.vercel.app/