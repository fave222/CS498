


import styles from "@/styles/Settings.module.css";

import Settings from "@/components/settings";

export default function SettingsPage() {




    return (
        
        <div className={styles.SettingsMain}>
            <Settings />
        </div>


    );
}